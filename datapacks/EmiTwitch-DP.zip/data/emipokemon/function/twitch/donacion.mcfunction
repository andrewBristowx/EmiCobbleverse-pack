# Donaciones (Streamlabs u otras): 1 tirada por dolar entero. Uso (como OP):
#   /function emipokemon:twitch/donacion {jugador:"NombreDeMinecraft",dolares:5}
# El jugador debe estar conectado. Los dolares son un numero entero (5, no 5.5). Maximo 1279 por llamada.
# Devuelve los dolares entregados ("returned 5") o 0 si no se entrego (jugador desconectado o menos de 1 dolar).
$execute unless entity @a[name="$(jugador)"] run tellraw @s [{"text":"Donacion NO entregada: ","color":"red"},{"text":"$(jugador)","color":"yellow"},{"text":" no esta conectado.","color":"red"}]
$execute unless entity @a[name="$(jugador)"] run return fail
$scoreboard players set #usd emitwitch_don $(dolares)
scoreboard players operation #total emitwitch_don = #usd emitwitch_don
execute if score #total emitwitch_don matches ..0 run tellraw @s [{"text":"Donacion sin tiradas: minimo 1 USD.","color":"red"}]
execute if score #total emitwitch_don matches ..0 run return fail
$execute if score #usd emitwitch_don matches 256.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_256
execute if score #usd emitwitch_don matches 256.. run scoreboard players remove #usd emitwitch_don 256
$execute if score #usd emitwitch_don matches 256.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_256
execute if score #usd emitwitch_don matches 256.. run scoreboard players remove #usd emitwitch_don 256
$execute if score #usd emitwitch_don matches 256.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_256
execute if score #usd emitwitch_don matches 256.. run scoreboard players remove #usd emitwitch_don 256
$execute if score #usd emitwitch_don matches 256.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_256
execute if score #usd emitwitch_don matches 256.. run scoreboard players remove #usd emitwitch_don 256
$execute if score #usd emitwitch_don matches 128.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_128
execute if score #usd emitwitch_don matches 128.. run scoreboard players remove #usd emitwitch_don 128
$execute if score #usd emitwitch_don matches 64.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_64
execute if score #usd emitwitch_don matches 64.. run scoreboard players remove #usd emitwitch_don 64
$execute if score #usd emitwitch_don matches 32.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_32
execute if score #usd emitwitch_don matches 32.. run scoreboard players remove #usd emitwitch_don 32
$execute if score #usd emitwitch_don matches 16.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_16
execute if score #usd emitwitch_don matches 16.. run scoreboard players remove #usd emitwitch_don 16
$execute if score #usd emitwitch_don matches 8.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_8
execute if score #usd emitwitch_don matches 8.. run scoreboard players remove #usd emitwitch_don 8
$execute if score #usd emitwitch_don matches 4.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_4
execute if score #usd emitwitch_don matches 4.. run scoreboard players remove #usd emitwitch_don 4
$execute if score #usd emitwitch_don matches 2.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_2
execute if score #usd emitwitch_don matches 2.. run scoreboard players remove #usd emitwitch_don 2
$execute if score #usd emitwitch_don matches 1.. run loot give $(jugador) loot emipokemon:twitch/random_tickets_1
execute if score #usd emitwitch_don matches 1.. run scoreboard players remove #usd emitwitch_don 1
$tellraw @a [{"text":"\u2726 ","color":"light_purple"},{"text":"$(jugador)","color":"gold","bold":true},{"text":" don\u00f3 ","color":"yellow"},{"text":"$(dolares) USD","color":"green"},{"text":" y recibe sus tiradas de gacha. \u00a1Gracias!","color":"yellow"}]
$return $(dolares)
