scoreboard objectives add emitwitch_don dummy
