advancement revoke @s only emicocina:festin_directo
execute store result score #now emicocina_festin run time query gametime
execute if score #count emicocina_festin matches 3.. if score #now emicocina_festin >= #ready emicocina_festin run scoreboard players set #count emicocina_festin 0
execute if score #count emicocina_festin matches 3.. run function emicocina:festin_bloqueado
execute unless score #count emicocina_festin matches 3.. run function emicocina:festin_activar
