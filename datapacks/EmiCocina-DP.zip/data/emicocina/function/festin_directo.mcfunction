# Se ejecuta (como el jugador, nivel 2) al terminar de comer el Festin del Directo.
advancement revoke @s only emicocina:festin_directo
emi twitch bonus activar
tellraw @a [{"selector":"@s","color":"gold"},{"text":" ha servido un ","color":"yellow"},{"text":"Festín del Directo","color":"gold","bold":true},{"text":" para todo el servidor.","color":"yellow"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.8 0.5 0.3 60
