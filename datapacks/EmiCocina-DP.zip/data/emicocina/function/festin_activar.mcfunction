scoreboard players set #ok emicocina_festin 0
execute store success score #ok emicocina_festin run emi twitch bonus activar
execute if score #ok emicocina_festin matches 0 run function emicocina:festin_fallo
execute if score #ok emicocina_festin matches 1 run function emicocina:festin_servido
