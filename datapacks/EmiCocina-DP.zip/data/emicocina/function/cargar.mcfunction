scoreboard objectives add emicocina_festin dummy
scoreboard players add #count emicocina_festin 0
scoreboard players add #ready emicocina_festin 0
scoreboard players set #cooldown emicocina_festin 72000
scoreboard players set #1200 emicocina_festin 1200
