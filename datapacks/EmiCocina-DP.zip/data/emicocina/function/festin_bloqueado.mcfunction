loot give @s loot emicocina:festin_directo
scoreboard players operation #left emicocina_festin = #ready emicocina_festin
scoreboard players operation #left emicocina_festin -= #now emicocina_festin
scoreboard players add #left emicocina_festin 1199
scoreboard players operation #left emicocina_festin /= #1200 emicocina_festin
tellraw @s [{"text":"⏳ Los Festines del Directo están en enfriamiento. Faltan ","color":"red"},{"score":{"name":"#left","objective":"emicocina_festin"},"color":"yellow"},{"text":" min. Te devolvimos el plato.","color":"red"}]
playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
