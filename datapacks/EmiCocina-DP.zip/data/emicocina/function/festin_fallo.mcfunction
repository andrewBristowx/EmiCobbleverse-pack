loot give @s loot emicocina:festin_directo
tellraw @s {"text":"No se pudo activar el bono ahora mismo. Te devolvimos el plato.","color":"red"}
playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
