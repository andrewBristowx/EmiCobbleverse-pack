scoreboard players operation #ready emicocina_festin = #now emicocina_festin
scoreboard players operation #ready emicocina_festin += #cooldown emicocina_festin
scoreboard players operation #cdmin emicocina_festin = #cooldown emicocina_festin
scoreboard players operation #cdmin emicocina_festin /= #1200 emicocina_festin
tellraw @a [{"text":"⏳ Se agotaron los Festines del Directo. Podrán servirse otra vez en ","color":"gray"},{"score":{"name":"#cdmin","objective":"emicocina_festin"},"color":"yellow"},{"text":" min.","color":"gray"}]
