scoreboard players add #count emicocina_festin 1
effect give @s minecraft:regeneration 60 1
effect give @s minecraft:absorption 120 3
effect give @s cobblecuisine:exp_boost 600 0
effect give @s cobblecuisine:catch_boost 600 0
tellraw @a [{"selector":"@s","color":"gold"},{"text":" ha servido un ","color":"yellow"},{"text":"Festín del Directo","color":"gold","bold":true},{"text":" para todo el servidor.","color":"yellow"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.8 0.5 0.3 60
execute if score #count emicocina_festin matches 3.. run function emicocina:festin_agotado
